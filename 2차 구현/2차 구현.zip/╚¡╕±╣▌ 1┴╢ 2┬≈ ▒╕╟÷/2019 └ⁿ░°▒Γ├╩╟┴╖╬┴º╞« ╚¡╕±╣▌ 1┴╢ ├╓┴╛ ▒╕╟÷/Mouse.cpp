#include "Mouse.h"
#include <algorithm> 
#include <cctype> 
int tel = 0;   // save ������ �ε���
int teleport_number = 1;      // �ڷ���Ʈ�� ����� Ƚ��
int teleport_count = 1; // �ڷ���Ʈ�� ����ϱ� ���� ī��Ʈ

Mouse::Mouse(Maze& maze) // ������
{
	row = maze.row;
	col = maze.col;
	m_col = maze.entrance_col;
	m_row = maze.entrance_row;
	energy = row * col * 2;
	memory = (MEMORY * *)malloc((row) * sizeof(MEMORY*));
	for (i = 0; i < row; i++)
	{
		memory[i] = (MEMORY*)malloc((col) * sizeof(MEMORY));
	}
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			memory[i][j].trace = 0;

			if (i == 0 || i == row - 1) // �ܰ��� (��, �Ʒ�)
			{
				memory[i][j].state = 1;
				memory[i][j].trace = 1;
			}
		}
		memory[i][0].state = 1; // �ܰ��� (����, ������)
		memory[i][0].trace = 1;

		memory[i][col - 1].state = 1;
		memory[i][col - 1].trace = 1;
	}

	save = (Point * *)malloc((row * 100) * sizeof(Point*));   // ������ ��ǥ ���� ������
	for (i = 0; i < row * 100; i++)
	{
		save[i] = (Point*)malloc((col * 100) * sizeof(Point));
	} // �����Ҵ�

	save[tel] = new Point(m_row, m_col, teleport_count);
}
bool Mouse::asktp() {

	string tpanswer;

	while (1) {
		gotoxy(col * 2 + 2, 20 + (++teleport_number));
		txtcolor(15);
		cout << "�ڷ���Ʈ ����Ͻ�? (Y/N)\n" << endl;
		gotoxy(col * 2 + 2, 20 + (++teleport_number));

		getline(cin, tpanswer);
		if (tpanswer == "y") {
			return true;
		}

		else if (tpanswer == "n") {
			return false;
		}
		else {
			gotoxy(col * 2 + 2, 20 + (++teleport_number));
			cout << "�߸��� �Է��Դϴ�\n";
		}
	}
}

void Mouse::movePaint(int** map)
{
	txtcolor(14);
	gotoxy(col * 2 + 2, 13);
	cout << "������: " << energy << "������";
	gotoxy(col * 2 + 2, 9);
	cout << "��ǥ: " << m_row << ", " << m_col << "������";
	gotoxy(m_col * 2, m_row); // �� ��Ÿ����
	cout << "��";
	gotoxy(col * 2 + 2, 15);
}

void Mouse::lookAround(int** map) // �ֺ��� �ѷ����� �޸𸮿� ���� + ������ ���� ��ȯ
{
	int wayToGo = 0;

	int a = 0, b = 0;
	for (a = m_row - 1; a <= m_row + 1; a++)
	{
		for (b = m_col - 1; b <= m_col + 1; b++)
		{
			if (a == m_row && b == m_col);
			else
			{
				memory[a][b].state = map[a][b];
				if (map[a][b] == 1)
					memory[a][b].trace = 1;
			}
		}
	}

	if (m_row - 2 >= 0 && m_col - 2 >= 0 && m_row + 2 <= row - 1 && m_col + 2 <= col - 1) // ���� �� ���ƹ�����
	{
		if (memory[m_row + 2][m_col].trace == 1 && memory[m_row + 1][m_col - 1].trace == 1 && memory[m_row + 1][m_col + 1].trace == 1)
			memory[m_row + 1][m_col].trace = 1;
		if (memory[m_row - 2][m_col].trace == 1 && memory[m_row - 1][m_col - 1].trace == 1 && memory[m_row - 1][m_col + 1].trace == 1)
			memory[m_row - 1][m_col].trace = 1;
		if (memory[m_row][m_col - 2].trace == 1 && memory[m_row - 1][m_col - 1].trace == 1 && memory[m_row + 1][m_col - 1].trace == 1)
			memory[m_row][m_col - 1].trace = 1;
		if (memory[m_row][m_col + 2].trace == 1 && memory[m_row + 1][m_col + 1].trace == 1 && memory[m_row - 1][m_col + 1].trace == 1)
			memory[m_row][m_col + 1].trace = 1;
	}

	if (memory[m_row][m_col + 1].state == 0)
		wayToGo++; // �� �� �ִ� �� ����ϱ�
	if (memory[m_row + 1][m_col].state == 0)
		wayToGo++;
	if (memory[m_row][m_col - 1].state == 0)
		wayToGo++;
	if (memory[m_row - 1][m_col].state == 0)
		wayToGo++;
	if (memory[m_row][m_col + 1].trace == 1 && memory[m_row + 1][m_col].trace == 1 && memory[m_row][m_col - 1].trace == 1 && memory[m_row - 1][m_col].trace == 1) // �� ���� ���� ��� (���� ����)
		wayToGo = 1;

	gotoxy(col * 2 + 2, 17);
	txtcolor(14);
	memory[m_row][m_col].crossroads = wayToGo;
	cout << "�� �� �ִ� ��: " << wayToGo << "��";
}
bool is_digits(const std::string& str) {
	return str.find_first_not_of("0123456789") == std::string::npos;
}

char* string_to_char(string a) {
	char ch[100];
	strcpy_s(ch, a.c_str());
	return ch;
}
void Mouse::strategy(int** map)
{
	gotoxy(m_col * 2, m_row);
	cout << "��";         // ������ġ ������
	lookAround(map);

	if (memory[m_row][m_col].crossroads == 1)
	{
		memory[m_row][m_col].trace = 1;

		save[tel]->cnt = teleport_count;
		if (save[tel]->cnt >= 15)   // �ڷ���Ʈ ��� ���� ���� ���� ��
		{
			int tmp_row = 1, tmp_col = 1;

			if (asktp()) {
				while (1) {
					bool is_correct_input = false;
					while (!is_correct_input) {
						//string ttp1, ttp2;
						tprow = -1;
						tpcol = -1;
						string tp_cord = "";
						gotoxy(col * 2 + 2, 20 + (++teleport_number));
						cout << "x y ��ǥ �Է�";
						gotoxy(col * 2 + 2, 20 + (++teleport_number));
						getline(std::cin, tp_cord);


						if (tp_cord.empty()) {
							gotoxy(col * 2 + 2, 20 + (++teleport_number));
							cout << "�ùٸ� ������ �ƴմϴ�.";
						}
						else {
							switch (tp_cord.length())
							{
							case 3:
								if (tp_cord.substr(1, 1) == " ") {
									if (is_digits(tp_cord.substr(0, 1))) {
										tprow = stoi(tp_cord.substr(0, 1));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "x�� �ùٸ� ������ �ƴմϴ�.";
									}
									if (is_digits(tp_cord.substr(2, 1))) {
										tpcol = stoi(tp_cord.substr(2, 1));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "y�� �ùٸ� ������ �ƴմϴ�.";
									}
								}
								else {
									gotoxy(col * 2 + 2, 20 + (++teleport_number));
									cout << "x y ������ �ƴմϴ�.";
								}
								break;
							case 4:
								if (tp_cord.substr(1, 1) == " ") {
									if (is_digits(tp_cord.substr(0, 1))) {
										tprow = stoi(tp_cord.substr(0, 1));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "x�� �ùٸ� ������ �ƴմϴ�.";
									}
									if (is_digits(tp_cord.substr(2, 3))) {
										tpcol = stoi(tp_cord.substr(2, 3));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "y�� �ùٸ� ������ �ƴմϴ�.";
									}
								}
								else if (tp_cord.substr(2, 1) == " ") {
									if (is_digits(tp_cord.substr(0, 2))) {
										tprow = stoi(tp_cord.substr(0, 2));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "x�� �ùٸ� ������ �ƴմϴ�.";
									}
									if (is_digits(tp_cord.substr(3, 1))) {
										tpcol = stoi(tp_cord.substr(3, 1));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "y�� �ùٸ� ������ �ƴմϴ�.";
									}
								}
								else {
									gotoxy(col * 2 + 2, 20 + (++teleport_number));
									cout << "x y ������ �ƴմϴ�.";
								}
								break;
							case 5:
								if (tp_cord.substr(2, 1) == " ") {
									if (is_digits(tp_cord.substr(0, 2))) {
										tprow = stoi(tp_cord.substr(0, 2));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "x�� �ùٸ� ������ �ƴմϴ�.";
									}
									if (is_digits(tp_cord.substr(3, 2))) {
										tpcol = stoi(tp_cord.substr(3, 2));
										is_correct_input = true;
									}
									else {
										gotoxy(col * 2 + 2, 20 + (++teleport_number));
										cout << "y�� �ùٸ� ������ �ƴմϴ�.";
									}
								}
								else {
									gotoxy(col * 2 + 2, 20 + (++teleport_number));
									cout << "�ùٸ� ������ �ƴմϴ�.";
								}
								break;
							default:
								gotoxy(col * 2 + 2, 20 + (++teleport_number));
								cout << "�ùٸ� ������ �ƴմϴ�.";
								break;
							}
						}
						teleport_number++;
					}

					if (tprow <= 50 && tprow >= 0 && tpcol <= 30 && tpcol >= 0) {
						if (memory[tprow][tpcol].trace == 1 && memory[tprow][tpcol].state == 0) {
							m_row = tprow;
							m_col = tpcol;
							gotoxy(col * 2 + 2, 20 + (++teleport_number));
							//����					cout << teleport_count << "         ";
							//cout << memory[tprow][tpcol].tptp;
							int mango = teleport_count - memory[tprow][tpcol].tptp;
							gotoxy(m_col * 2, m_row);
							cout << "��";

							for (int k = 0; k < mango; k++) {
								alreadyStack.Pop();
								alreadyStack.size--;
							}
							teleport_count = 0;
							break;
						}
						else {
							gotoxy(col * 2 + 2, 20 + (++teleport_number));
							cout << "�� �� ���� ���̾�";
							teleport_number++;
						}
					}
					else {
						gotoxy(col * 2 + 2, 20 + (++teleport_number));
						cout << "�� �� ���� ���̾�";
						teleport_number++;

					}
				}
			}
			else {
				gotoxy(m_col * 2, m_row);
				teleport_count = 1;
			}
		}
		else
		{
			alreadyStack.Pop();
			m_col = alreadyStack.Top->col;
			m_row = alreadyStack.Top->row;
			energy--;
			alreadyStack.size--;
		}
	}
	else {
		if (memory[m_row][m_col + 1].trace == 0)   // ������
		{
			memory[m_row][m_col].trace = 1;
			m_col++;
			alreadyStack.Push(m_row, m_col);
			energy--;
			teleport_count++;
			memory[m_row][m_col].tptp = teleport_count;
		}
		else if (memory[m_row + 1][m_col].trace == 0)   // �Ʒ�
		{
			memory[m_row][m_col].trace = 1;
			m_row++;
			alreadyStack.Push(m_row, m_col);
			energy--;
			teleport_count++;
			memory[m_row][m_col].tptp = teleport_count;
		}
		else if (memory[m_row][m_col - 1].trace == 0)   // ����
		{
			memory[m_row][m_col].trace = 1;
			m_col--;
			alreadyStack.Push(m_row, m_col);
			energy--;
			teleport_count++;
			memory[m_row][m_col].tptp = teleport_count;
		}
		else if (memory[m_row - 1][m_col].trace == 0)   // ����
		{
			memory[m_row][m_col].trace = 1;
			m_row--;
			alreadyStack.Push(m_row, m_col);
			energy--;
			teleport_count++;
			memory[m_row][m_col].tptp = teleport_count;
		}
		else if (m_row != 1 && m_row != 0 && memory[m_row - 1][m_col].trace == 0) // ���� (�� ���� ��쵵 ��������)
		{
			memory[m_row][m_col].trace = 1;
			m_row--;
			alreadyStack.Push(m_row, m_col);
			energy--;
			teleport_count++;
			memory[m_row][m_col].tptp = teleport_count;
		}
	}

	lookAround(map);
}
